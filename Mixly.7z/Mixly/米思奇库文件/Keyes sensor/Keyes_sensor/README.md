# keyes Library v0.40

Arduino Library for Easy Electronic Modules

How to use:

1. Download the source from the git https://keyes.COM/

2. copy the keyes folder to your arduino default library. Your Arduino library folder should now look like this 
   (on Windows): [arduino installation directory]\libraries\keyes\src
   (On MACOS): [arduino Package Contents]\contents\Jave\libraries\keyes\src

3. Open the Arduino Application. (If it's already open, you will need to restart it to see changes.)

4. Click "File-> Examples". Here are some test programs in keyes -> example


